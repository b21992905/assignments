#include <iostream>
#include <fstream>
#include <string>
#include <istream>
#include <vector>
using namespace std;
int point;
vector<int> store;
void PutIn(int** A,int name,int x,int y,int arraysize);
void ControlEnvironment(int** A,int name,int x,int y,int arraysize);
void Bomb(int** A,int x,int y,int size);
void Addvector(int** A,int a,int b);
int main(int argc,char *argv[]) {
    ifstream  data(argv[1]);
    ifstream data2(argv[2]);
    ofstream output(argv[3]);
    int** arr;
    int line[3]={0,0,0};
    int a=101;int arraysize;
    if(data.is_open()){// reads to input1.txt
        while(data.good()){
            if(a==101){
                data>>arraysize;a=arraysize;
                arr=new int*[arraysize];
                for(int i=0;i<arraysize;i++){
                    arr[i]=new int[arraysize];
                    for(int j=0;j<arraysize;j++){
                       arr[i][j]=0;
                    }
                }
            }else{
                for(int i=0;i<3;i++){
                    if(line[i]==0){
                        data>>a;
                        line[i]=a;
                    }
                }
                PutIn(arr,line[0],line[1],line[2],arraysize);
                line[0]=line[1]=line[2]=0;
            }
        }
    }
    int gridsize;int** arr2;int z=23;int x;int y;
    if(data2.is_open()){//reads to input2.txt
        while(data2.good()) {
            if(z==23){
            data2 >> gridsize;z=1;
            arr2 = new int *[gridsize];
            for (int i = 0; i < gridsize; i++) {
                arr2[i] = new int[gridsize];
                for (int j = 0; j < gridsize; j++) {
                    data2 >> arr2[i][j];
                }
            }
            }else{
                data2>>x;data2>>y;
                Bomb(arr2,x,y,gridsize);
            }
        }
    }
    //writes to the output file
    output<<"PART 1:"<<endl;
    for(int i=0;i<arraysize;i++){
        for(int j=0;j<arraysize;j++){
            output<<arr[i][j]<<" ";
        }
        output<<"\n";
    }
    output<<"\n";
    output<<"PART 2:"<<endl;
    for(int i=0;i<gridsize;i++){
        for(int j=0;j<gridsize;j++){
            output<<arr2[i][j]<<" ";
        }
        output<<"\n";
    }
    output<<"Final Point: "<<point<<"p"<<endl;
    output.close();
    return 0;
}
void Bomb(int** A,int x,int y,int size){
    int name=A[x][y];
    int number=0;
    for(int i=0;i<size;i++){
         if(A[i][y]==name){
             number++;
             A[i][y]=0;
         }
    }
    for(int j=0;j<size;j++){
        if(A[x][j]==name){
            number++;
            A[x][j]=0;
        }
    }
    int x1=x;int y1=y;
    while(x1>0 && y1>0){
        x1--;y1--;
        if(A[x1][y1]==name){
            A[x1][y1]=0;number++;
        }
    }
    x1=x;y1=y;
    while(x1<size-1 && y1<size-1){
        x1++;y1++;
        if(A[x1][y1]==name){
            A[x1][y1]=0;number++;
        }
    }
    x1=x;y1=y;
    while(x1<size-1 && y1>0){
        x1++;y1--;
        if(A[x1][y1]==name){
            A[x1][y1]=0;number++;
        }
    }
    x1=x;y1=y;
    while(x1>0 && y1<size-1){
        x1--;y1++;
        if(A[x1][y1]==name){
            A[x1][y1]=0;number++;
        }
    }
    point += number*name;
}
void PutIn(int** A,int name,int x,int y,int arraysize){// changes some values in grid
    ControlEnvironment(A,name,x,y,arraysize);
    if(store.size()>=4){
        for(int i=0;i<store.size();(i=i+2)){
            A[store[i]][store[i+1]]=0;
        }
        store.clear();
        PutIn(A,name+1,x,y,arraysize);
    }else{
        for(int i=0;i<store.size();(i=i+2)){
            A[store[i]][store[i+1]]=name;
        }
        store.clear();
        A[x][y]=name;
    }
}
void Addvector(int** A,int a,int b){//stores some places that have same values
    for(int i=0;i<store.size();(i=i+2)){
        if(store[i]==a && store[i+1]==b){
            return;
        }
    }
    A[a][b]=0;
    store.push_back(a);store.push_back(b);
}
void ControlEnvironment(int** A,int name,int x,int y,int arraysize){
    if(x-1>=0 && A[x-1][y]==name){//control of up
        Addvector(A,x-1,y);
        ControlEnvironment(A,name,x-1,y,arraysize);
    }if(x+1<arraysize && A[x+1][y]==name){//control of down
        Addvector(A,x+1,y);
        ControlEnvironment(A,name,x+1,y,arraysize);
    }if(y-1>=0 && A[x][y-1]==name){//control of left
        Addvector(A,x,y-1);
        ControlEnvironment(A,name,x,y-1,arraysize);
    }if(y+1<arraysize && A[x][y+1]==name){//control of right
        Addvector(A,x,y+1);
        ControlEnvironment(A,name,x,y+1,arraysize);
    }
}