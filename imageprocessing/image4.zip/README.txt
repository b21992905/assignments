The ncc function takes two images as parameters and calculates the normalized cross correlations. 
The match_template function hovers the template image over the target image and finds the most similar region.
The find_target function examines the similarity of the image with all templates and uses the match_template function for this.
Finally, it returns the target value of whichever template image it most closely resembles.
In this assignment I have tagged all the given pictures using all these functions. 
Finally, I compared these prediction label values ​​with the correct values ​​and calculated the accuracy.
