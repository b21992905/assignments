I read the first pictures from the drive. I separated the pictures according to the LAB color scale.
Then I performed the necessary operations for the color transfer.
In Part2, I created the divided_img function to split the pictures into pieces of different sizes.
At the same time, I wrote the coloring function that performs the operations in part1 for color transfer.
Then I created the sum_of_squared function, which I use the ssd method to find the most similar parts in the target and source image.
I divided the pictures into equal parts and performed color transfer according to the most similar parts.
As a result, I combined these pieces that I had divided and turned them into a picture.