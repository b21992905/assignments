Firstly, I read my image files then I created mask image 
Then I created the mask images. While creating the mask images, 
I made the region adjustment differently according to the images.
 I created the generate-gaussian function. This function takes 
the picture and the pyramid level as input and creates and 
returns the gaussian pyramid. The Generate-laplacian function takes
 this gaussian pyramid and transforms it into a laplacian pyramid. 
Then I created the blend function to do the blending process
 according to the given formula.
 Finally, I reconstructed the pyramid and turned it into a picture.
 I repeated these operations for 5 different images and 3 different
 pyramid levels. These levels are 3.7, and 10.