import java.util.ArrayList;
class Queue {
    private String id;
    private String name;
    private int number;
    public static ArrayList<Queue> tokens=new ArrayList<>();//token's list

    public Queue(String id, String name, int number) {
        this.id = id;
        this.name = name;
        this.number = number;
    }
    public String getId() {
        return id;
    }
    public String getName() {
        return name;
    }

    public int getNumber() {
        return number;
    }
    public void setNumber(int number) {
        this.number -= number;
    }
    public static void sorting(){//to change the place of token which is reduced
        Queue q2=tokens.get(tokens.size()-1);
        for(int i=0;i<tokens.size();i++){
            if(q2.getNumber()>tokens.get(i).getNumber()){
                tokens.add(i,q2);tokens.remove(tokens.size()-1);
                break;
            }
        }
    }
    public static void addQueue(String x){//to reduce tokens
        String[] array3=x.split(",");
        for(int j=0;j<tokens.size();j++){
            if(array3[0].startsWith(tokens.get(j).getName())){
                if(tokens.get(j).getNumber()>=Integer.parseInt(array3[1])){
                    tokens.get(j).setNumber(Integer.parseInt(array3[1]));
                    if(tokens.get(j).getNumber()==0){
                        tokens.remove(j);
                    }else {
                        Queue q=tokens.get(j);
                        tokens.remove(j);tokens.add(q);sorting();
                    }

                }else{
                    int ek=tokens.get(j).getNumber();
                    tokens.get(j).setNumber(Integer.parseInt(array3[1]));
                    tokens.remove(j);
                    String s=array3[0]+",";
                    addQueue(s+String.valueOf(Integer.parseInt(array3[1])-ek));
                }
            break;
            }
        }
    }

}
