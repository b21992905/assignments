import java.util.ArrayList;
class Stack{
    private String name;
    private ArrayList<String> items=new ArrayList<>();//object's items list

    public Stack(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public ArrayList<String> getItems() {
        return items;
    }
    public void firstOut(int a){//removes items from the items list
        ArrayList<String> test=new ArrayList<>();
        for(int i=0;i<items.size()-a;i++){
            test.add(items.get(i));
        }
        items=test;
    }
    public static void lastIn(String p,ArrayList<Stack> list){//adds items to the items list
        for(Stack c:list){
            if(p.startsWith(c.getName())){
                String[] array2=p.split(",");
                for(int i=1;i<array2.length;i++){
                    c.getItems().add(array2[i]);
                }
            }
        }
    }

    @Override
    public String toString() {
        String son = "";
        for(int i=this.items.size()-1;i>=0;i--){
            son+=items.get(i)+"\n";
        }
        if(items.size()==0){
            son="\n";
        }
        return this.name+":\n"+son+"---------------\n";
    }
}
