import java.io.*;
import java.util.ArrayList;
public class Main {
    public static void main(String[] args){
        String fis1=args[0];String fis2=args[1];String fis3=args[2];String fis4=args[3];String fis5=args[4];
        BufferedWriter out=null;
        try{
            BufferedReader file1=new BufferedReader(new FileReader(fis1));
            BufferedReader file2=new BufferedReader(new FileReader(fis2));
            BufferedReader file3=new BufferedReader(new FileReader(fis3));
            BufferedReader file4=new BufferedReader(new FileReader(fis4));
            out=new BufferedWriter(new FileWriter(fis5,false));
            out=new BufferedWriter(new FileWriter(fis5,true));String lines;
            ArrayList<Stack> elements=new ArrayList<>();
            while ((lines=file1.readLine())!=null){//reads parts.txt
                elements.add(new Stack(lines));
            }
            while ((lines=file2.readLine())!=null){//reads items.txt
                String[] item=lines.split(" ");
                for(Stack s:elements){
                    if(s.getName().equals(item[1])){
                        s.getItems().add(item[0]);break;
                    }
                }
            }
            while ((lines=file3.readLine())!=null){//reads tokens.txt
                String[] token=lines.split(" ");
                Queue.tokens.add(new Queue(token[0],token[1],Integer.parseInt(token[2])));Queue.sorting();
            }
            while ((lines=file4.readLine())!=null){//reads tasks.txt
                String[] missions=lines.split("\t");
                if(missions[0].equals("BUY")){// to buy items
                    for(String b:missions){
                        for(Stack c:elements){
                            if(b.startsWith(c.getName())){
                                String[] array=b.split(",");
                                c.firstOut(Integer.parseInt(array[1]));
                            }
                        }
                    }
                    for(int i=1;i<missions.length;i++){
                        Queue.addQueue(missions[i]);
                    }
                }else{//to put items
                    for(String p:missions){
                        Stack.lastIn(p,elements);
                    }
                }
            }
            //to write to the output file
            for(Stack c:elements){
                out.write(c.toString());
            }
            out.write("Token Box:");
            for(int s=Queue.tokens.size()-1;s>=0;s--){
                out.write("\n"+Queue.tokens.get(s).getId()+" "+Queue.tokens.get(s).getName()+" "+Queue.tokens.get(s).getNumber());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            if(out!=null){
                try {
                    out.close();//to close the file
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
